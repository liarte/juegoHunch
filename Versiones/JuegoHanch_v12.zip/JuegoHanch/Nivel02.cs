﻿
public class Nivel02 : Nivel
{

    public Nivel02()
    {
        nombre = "Nivel 2";
        datosNivelIniciales[0] = "                                ";
        datosNivelIniciales[1] = " TTTTT                          ";
        datosNivelIniciales[2] = "                                ";
        datosNivelIniciales[3] = "                      TTTTTTT   ";
        datosNivelIniciales[4] = "                        C   L   ";
        datosNivelIniciales[5] = "                            L   ";
        datosNivelIniciales[6] = "            SSSSSSS         L   ";
        datosNivelIniciales[7] = "    SSSSS                   L   ";
        datosNivelIniciales[8] = "                            L   ";
        datosNivelIniciales[9] = "SSSSS   SSSSSSSSS   SSSSSSSSSSSS";
        datosNivelIniciales[10] ="SSSSS   SSSSSSSSS   SSSSSSSSSSSS";
        datosNivelIniciales[11] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[12] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[13] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[14] ="                                ";
        datosNivelIniciales[15] ="                                ";

        Reiniciar();
    }

} /* fin de la clase Nivel01 */

﻿
public class Nivel01 : Nivel
{

    public Nivel01()
    {
        nombre = "Nivel 1";
        datosNivelIniciales[0] = "                                ";
        datosNivelIniciales[1] = " TTTTT                          ";
        datosNivelIniciales[2] = "                                ";
        datosNivelIniciales[3] = "                       TTTTTTT  ";
        datosNivelIniciales[4] = "                       C     L  ";
        datosNivelIniciales[5] = "                             L  ";
        datosNivelIniciales[6] = "                             L  ";
        datosNivelIniciales[7] = "                             L  ";
        datosNivelIniciales[8] = "       V      V              L  ";
        datosNivelIniciales[9] = "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[10] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[11] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[12] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[13] ="SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS";
        datosNivelIniciales[14] ="                                ";
        datosNivelIniciales[15] ="                                ";

        Reiniciar();
    }

} /* fin de la clase Nivel01 */
